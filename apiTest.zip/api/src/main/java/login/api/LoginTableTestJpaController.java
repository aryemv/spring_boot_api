/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login.api;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import login.api.exceptions.NonexistentEntityException;
import login.api.exceptions.PreexistingEntityException;

/**
 *
 * @author arye
 */
public class LoginTableTestJpaController implements Serializable {

    public LoginTableTestJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(LoginTableTest loginTableTest) throws PreexistingEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(loginTableTest);
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findLoginTableTest(loginTableTest.getUserName()) != null) {
                throw new PreexistingEntityException("LoginTableTest " + loginTableTest + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(LoginTableTest loginTableTest) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            loginTableTest = em.merge(loginTableTest);
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                String id = loginTableTest.getUserName();
                if (findLoginTableTest(id) == null) {
                    throw new NonexistentEntityException("The loginTableTest with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(String id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            LoginTableTest loginTableTest;
            try {
                loginTableTest = em.getReference(LoginTableTest.class, id);
                loginTableTest.getUserName();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The loginTableTest with id " + id + " no longer exists.", enfe);
            }
            em.remove(loginTableTest);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<LoginTableTest> findLoginTableTestEntities() {
        return findLoginTableTestEntities(true, -1, -1);
    }

    public List<LoginTableTest> findLoginTableTestEntities(int maxResults, int firstResult) {
        return findLoginTableTestEntities(false, maxResults, firstResult);
    }

    private List<LoginTableTest> findLoginTableTestEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(LoginTableTest.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public LoginTableTest findLoginTableTest(String id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(LoginTableTest.class, id);
        } finally {
            em.close();
        }
    }

    public int getLoginTableTestCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<LoginTableTest> rt = cq.from(LoginTableTest.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
