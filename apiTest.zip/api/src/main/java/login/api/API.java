/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login.api;

import java.nio.charset.StandardCharsets;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author arye
 */
@RestController
@RequestMapping(path = "login")
public class API {
    
    @PostMapping("tryLogin")
    public boolean loginTry(@RequestBody byte[] json) {
        String str = new String(json, StandardCharsets.UTF_8);
        if (Login.checkDetails(str)) {
           return true;
       }
        return false;
    }

    @PostMapping("newUser")
    public boolean newUser(@RequestBody byte[] bytes) {

        String str = new String(bytes, StandardCharsets.UTF_8);
        return Login.newUser(str);
    }
    
}
