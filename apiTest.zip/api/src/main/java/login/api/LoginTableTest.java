/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login.api;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author arye
 */
@Entity
@Table(name = "loginTableTest")
@NamedQueries({
    @NamedQuery(name = "LoginTableTest.findAll", query = "SELECT l FROM LoginTableTest l"),
    @NamedQuery(name = "LoginTableTest.findByUserName", query = "SELECT l FROM LoginTableTest l WHERE l.userName = :userName"),
    @NamedQuery(name = "LoginTableTest.findByPassword", query = "SELECT l FROM LoginTableTest l WHERE l.password = :password")})
public class LoginTableTest implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "userName")
    private String userName;
    @Basic(optional = false)
    @Column(name = "password")
    private String password;

    public LoginTableTest() {
    }

    public LoginTableTest(String userName) {
        this.userName = userName;
    }

    public LoginTableTest(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (userName != null ? userName.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof LoginTableTest)) {
            return false;
        }
        LoginTableTest other = (LoginTableTest) object;
        if ((this.userName == null && other.userName != null) || (this.userName != null && !this.userName.equals(other.userName))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "login.api.LoginTableTest[ userName=" + userName + " ]";
    }
    
}
