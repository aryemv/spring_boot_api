/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login.api;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 *
 * @author arye
 */
public class Login {
    
    static EntityManagerFactory emf = Persistence.createEntityManagerFactory("login_api_jar_0.0.1-SNAPSHOTPU");
    static LoginTableTestJpaController controller = new LoginTableTestJpaController(emf);
    static JSONParser parser = new JSONParser();
    
    public static boolean checkDetails(String strJson) {
        JSONObject json = null;
        try{
            json = (JSONObject)parser.parse(strJson);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(json);
        String userName = String.valueOf(json.get("userName"));
        String password = String.valueOf(json.get("password"));
        System.out.println(userName);
        LoginTableTest user = controller.findLoginTableTest(userName);

        if (user == null) {
            return false;
        } else if (user.getPassword().equals(password)) {
            return true;
        }
        return false;
    }
    
    public static boolean newUser(String strJson){
        
        JSONObject json = null;
        try{
            json = (JSONObject)parser.parse(strJson);
        } catch (Exception e) {
            e.printStackTrace();
        }
        String userName = String.valueOf(json.get("userName"));
        String password = String.valueOf(json.get("password"));
        LoginTableTest user = new LoginTableTest(userName, password);
        try{
            controller.create(user);
            return true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }
    
}
